import { Injectable } from '@angular/core';
import Web3 from 'web3';
import { Contract } from 'web3-eth-contract';

@Injectable({
  providedIn: 'root'
})
export class BlockchainService {
  private web3: Web3;
  private contract: Contract;
  private contractAddress = 'YOUR_CONTRACT_ADDRESS';
  private contractABI = [
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "id",
          "type": "uint256"
        },
        {
          "indexed": false,
          "internalType": "string",
          "name": "documentHash",
          "type": "string"
        },
        {
          "indexed": false,
          "internalType": "address",
          "name": "createdBy",
          "type": "address"
        },
        {
          "indexed": false,
          "internalType": "uint256",
          "name": "timestamp",
          "type": "uint256"
        }
      ],
      "name": "RecordCreated",
      "type": "event"
    },
    {
      "inputs": [],
      "name": "recordCount",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "",
          "type": "uint256"
        }
      ],
      "name": "records",
      "outputs": [
        {
          "internalType": "uint256",
          "name": "id",
          "type": "uint256"
        },
        {
          "internalType": "string",
          "name": "documentHash",
          "type": "string"
        },
        {
          "internalType": "address",
          "name": "createdBy",
          "type": "address"
        },
        {
          "internalType": "uint256",
          "name": "timestamp",
          "type": "uint256"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "string",
          "name": "_documentHash",
          "type": "string"
        }
      ],
      "name": "createRecord",
      "outputs": [],
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "inputs": [
        {
          "internalType": "uint256",
          "name": "_id",
          "type": "uint256"
        }
      ],
      "name": "getRecord",
      "outputs": [
        {
          "components": [
            {
              "internalType": "uint256",
              "name": "id",
              "type": "uint256"
            },
            {
              "internalType": "string",
              "name": "documentHash",
              "type": "string"
            },
            {
              "internalType": "address",
              "name": "createdBy",
              "type": "address"
            },
            {
              "internalType": "uint256",
              "name": "timestamp",
              "type": "uint256"
            }
          ],
          "internalType": "struct LegalRecord.Record",
          "name": "",
          "type": "tuple"
        }
      ],
      "stateMutability": "view",
      "type": "function"
    }
];

  constructor() {
    this.web3 = new Web3(new Web3.providers.HttpProvider('https://rinkeby.infura.io/v3/YOUR_INFURA_PROJECT_ID'));
    this.contract = new this.web3.eth.Contract(this.contractABI, this.contractAddress);
  }

  async createRecord(documentHash: string, privateKey: string): Promise<any> {
    const account = this.web3.eth.accounts.privateKeyToAccount(privateKey);
    this.web3.eth.accounts.wallet.add(account);

    const transaction = this.contract.methods.createRecord(documentHash);

    const options = {
      to: this.contractAddress,
      data: transaction.encodeABI(),
      gas: await transaction.estimateGas({ from: account.address }),
      gasPrice: await this.web3.eth.getGasPrice()
    };

    const signed = await this.web3.eth.accounts.signTransaction(options, privateKey);
    return this.web3.eth.sendSignedTransaction(signed.rawTransaction);
  }

  async getRecord(id: number): Promise<any> {
    return this.contract.methods.getRecord(id).call();
  }

  async getRecordCount(): Promise<number> {
    return this.contract.methods.recordCount().call();
  }
}
