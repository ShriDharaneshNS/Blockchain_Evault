import { Component } from '@angular/core';
import { BlockchainService } from '../blockchain.service';

@Component({
  selector: 'app-create-record',
  templateUrl: './create-record.component.html',
  styleUrls: ['./create-record.component.css']
})
export class CreateRecordComponent {
  documentHash: string = '';
  privateKey: string = '';

  constructor(private blockchainService: BlockchainService) { }

  async createRecord() {
    try {
      const receipt = await this.blockchainService.createRecord(this.documentHash, this.privateKey);
      console.log('Transaction receipt: ', receipt);
    } catch (error) {
      console.error('Error creating record: ', error);
    }
  }
}
