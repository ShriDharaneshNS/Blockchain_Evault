import { Component } from '@angular/core';

@Component({
  selector: 'app-view-records',
  standalone: true,
  imports: [],
  templateUrl: './view-records.component.html',
  styleUrl: './view-records.component.css'
})
export class ViewRecordsComponent {

}
