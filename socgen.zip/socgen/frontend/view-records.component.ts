import { Component, OnInit } from '@angular/core';
import { BlockchainService } from '../blockchain.service';

@Component({
  selector: 'app-view-records',
  templateUrl: './view-records.component.html',
  styleUrls: ['./view-records.component.css']
})
export class ViewRecordsComponent implements OnInit {
  records: any[] = [];

  constructor(private blockchainService: BlockchainService) { }

  async ngOnInit() {
    await this.loadRecords();
  }

  async loadRecords() {
    try {
      const recordCount = await this.blockchainService.getRecordCount();
      this.records = [];
      for (let i = 1; i <= recordCount; i++) {
        const record = await this.blockchainService.getRecord(i);
        this.records.push(record);
      }
    } catch (error) {
      console.error('Error loading records: ', error);
    }
  }
}
